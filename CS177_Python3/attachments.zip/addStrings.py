def addStrings(str1,str2):    
    return int(eval(str2)) + int(eval(str1))

def main():
    print("sum =",addStrings("255","10"))
main()
