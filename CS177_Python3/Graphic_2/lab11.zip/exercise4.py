import matplotlib.pyplot as plt
from random import randrange

def main():
    x=[]
    y=[]
    for i in range(10000):
        a = randrange(-100,101)
        b = randrange(-100,101)
        x.append(a)
        y.append(b)
    #plt.axis('equal')
    for i in range(10000):
        a = x[i]
        b = y[i]
        if a*a + b*b <= 10000:
            plt.scatter(a,b,color='blue')
        else:
            plt.scatter(a,b,color='green')
    plt.savefig('exercise4.png')
main()
