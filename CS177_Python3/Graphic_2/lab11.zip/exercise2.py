import matplotlib.pyplot as pyplot
from random import randrange

def main():
    mylist=[]
    for i in range(100000):
        a = randrange(1,11)
        b = randrange(1,11)
        c = a + b 
        mylist.append(c)
    mylist1=[]
    pos = []
    for i in range(1,21):
        mylist1.append(mylist.count(i))  # count how may i occurs
        pos.append(i)   
    bar = pyplot.bar(pos, mylist1,width=1,color='yellow',align='center')
    pyplot.axis([0, 21, 0, 11000]) 
    pyplot.savefig('exercise2.png')
main()
