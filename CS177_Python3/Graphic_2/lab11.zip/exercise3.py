import matplotlib.pyplot as plt
from random import randrange

def main():
    mylist=[]
    for i in range(100000):
        a = randrange(1,11)
        b = randrange(1,11)
        c = randrange(1,11)
        d = randrange(1,11)
        e = a + b + c + d
        mylist.append(e)
    mylist1=[]
    mylist2=[]
    for i in range(1,41):
        mylist1.append(mylist.count(i))
        mylist2.append(i)
             
    bar = plt.bar(mylist2,mylist1,width=1,color='yellow',align='center')
    plt.axis([0, 41, 0, 7500])
    plt.savefig('exercise3.png')
main()
