import matplotlib.pyplot as pyplot
from random import randrange

def main():
    mylist=[]
    data  = []
    pos = []
    for i in range(100000):
        a = randrange(1,11)
        mylist.append(a)
    for i in range(1,11):
        data.append(mylist.count(i))  # count how may i occurs
        pos.append(i)  
    bar = pyplot.bar(pos, data, width=1, color='yellow',align='center')
    pyplot.axis([0, 11, 0, 11000])
    
    pyplot.savefig('exercise1.png')
main()
