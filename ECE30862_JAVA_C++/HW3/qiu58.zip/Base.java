public class Base {

   public Base( ) { }

  // Add any needed method(s) here.
    
    public void f1(int input){
        System.out.println("Base f1("+input+")");
    }
    
    // Polymorphism
    public void f1(){
        System.out.println("Base f1()");
    }

}

