public class Derived extends Base {

   public Derived( ) { }

  // Add any needed function(s) here.

    public void f1(float input){
        System.out.println("Derived f1("+input+")");
    }
}

