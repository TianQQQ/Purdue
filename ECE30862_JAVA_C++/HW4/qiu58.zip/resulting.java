Base f1
Derived f2
