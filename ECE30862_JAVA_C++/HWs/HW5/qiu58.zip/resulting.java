Base and b calls
B f1
B f1
B f3
B f1
B f3
 
D1 and d1 calls
D1 f1
D1 f1
D1 f3
D1 f5
D1 f1
D1 f3
D1 f5
 
d1.bCaller
B f1
D1 f3
 
D2 and d2 calls
D2 f1
D2 f1
D2 f3
D2 f5
D2 f7
D2 f1
D2 f3
D2 f4
D2 f5
D2 f7
 
