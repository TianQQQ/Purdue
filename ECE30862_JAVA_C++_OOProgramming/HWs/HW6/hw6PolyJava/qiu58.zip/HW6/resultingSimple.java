s.x: 0
s.y: 0
s2.x: 2
s2.y: 2
s = s2

s.x: 0
s.y: 0
s.getX(): 2
s.getY(): 2
s.y: 0
s2.x: 2
s2.y: 2
