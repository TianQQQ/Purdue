import java.io.*;

public class Simple {

   public int x;
   public int y;

   public Simple( ) {
      x = 0;
      y = 0;
   }

   public int getX( ) {return x;}
   public int getY( ) {return y;}
}
