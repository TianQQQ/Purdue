import java.io.*;

public class Simple2 extends Simple {

   public int x;
   public int y;

   public Simple2( ) {
      x = 2;
      y = 2;
   }

   public int getX( ) {return x;}
   public int getY( ) {return y;}
}
