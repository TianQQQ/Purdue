c01.a.intValue( ): 0
c01.b.intValue( ): 0
c02.a.intValue( ): 1
c02.b.intValue( ): 2
c11.a.intValue( ): 0
c11.b.intValue( ): 0
c11.c.floatValue( ): 1.5
c11.y: 0
c12.a.intValue( ): 3
c12.b.intValue( ): 4
c12.c.floatValue( ): 5.0
c02.getA( ): -1
c02.getB( ): -2
c02.getX( ): -1
c12.getA( ): -3
c12.getB( ): -4
c12.getC( ): 5.0
c12.getX( ): 0
